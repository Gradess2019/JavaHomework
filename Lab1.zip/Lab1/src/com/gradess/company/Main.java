package com.gradess.company;

public class Main {

    public static void main(String[] args) {
        for (String argument : args) {
            System.out.println(argument);
        }
    }
}
